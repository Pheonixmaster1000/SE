(function () {
  const slides = [
    {
      image:
        "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1920&q=80",
      title: "Where serious buyers meet trusted sellers",
      subtitle: "Transparent bidding, verified listings, and support when you need it.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1920&q=80",
      title: "Curated lots — from collectibles to tech",
      subtitle: "New auctions daily. Watch live countdowns and place your best offer.",
    },
    {
      image:
        "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1920&q=80",
      title: "Built for teams: buyer, seller, admin & support",
      subtitle: "Role-based dashboards so your marketplace stays secure at scale.",
    },
  ];

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s == null ? "" : String(s);
    return d.innerHTML;
  }

  function formatMoney(n) {
    const x = Number(n);
    if (Number.isNaN(x)) return "—";
    return x.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 });
  }

  function formatCountdown(iso) {
    const end = new Date(iso).getTime();
    const diff = end - Date.now();
    if (diff <= 0) return "Ended";
    const s = Math.floor(diff / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (d > 0) return `${d}d ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  }

  function initSlider() {
    const root = document.getElementById("hero-slider");
    if (!root) return;
    const track = root.querySelector(".hero-slider__slides");
    const dots = root.querySelector(".hero-slider__dots");
    const prev = root.querySelector(".hero-slider__prev");
    const next = root.querySelector(".hero-slider__next");

    slides.forEach((slide, i) => {
      const el = document.createElement("div");
      el.className = "hero-slide" + (i === 0 ? " is-active" : "");
      el.style.backgroundImage = `url(${slide.image})`;
      el.innerHTML = `<div class="hero-slide__overlay"></div>
        <div class="container hero-slide__inner">
          <h2>${escapeHtml(slide.title)}</h2>
          <p>${escapeHtml(slide.subtitle)}</p>
          <a href="#auth" class="btn btn-primary">Start bidding</a>
        </div>`;
      track.appendChild(el);

      const dot = document.createElement("button");
      dot.type = "button";
      dot.className = "hero-slider__dot" + (i === 0 ? " is-active" : "");
      dot.setAttribute("aria-label", `Slide ${i + 1}`);
      dot.addEventListener("click", () => go(i));
      dots.appendChild(dot);
    });

    let idx = 0;
    const total = slides.length;

    function go(i) {
      idx = (i + total) % total;
      track.querySelectorAll(".hero-slide").forEach((el, j) => {
        el.classList.toggle("is-active", j === idx);
      });
      dots.querySelectorAll(".hero-slider__dot").forEach((el, j) => {
        el.classList.toggle("is-active", j === idx);
      });
    }

    prev.addEventListener("click", () => go(idx - 1));
    next.addEventListener("click", () => go(idx + 1));

    setInterval(() => go(idx + 1), 7000);
  }

  async function loadFeatured() {
    const host = document.getElementById("featured-auctions");
    if (!host) return;
    const stat = document.getElementById("stat-live-count");
    try {
      const { auctions } = await fetch("/api/auctions").then((r) => r.json());
      const active = (auctions || []).filter((a) => a.status === "active");
      if (stat) stat.textContent = String(active.length);

      const top = active.slice(0, 6);
      if (!top.length) {
        host.innerHTML = '<p class="hint">No live auctions right now. Check back soon.</p>';
        return;
      }

      host.innerHTML = `<div class="auction-grid">${top
        .map((a) => {
          const img = escapeHtml(a.imageUrl || "");
          return `<article class="auction-tile">
            <div class="auction-tile__media">
              <img src="${img}" alt="${escapeHtml(a.title)}" loading="lazy" width="400" height="260" />
              <span class="auction-tile__time" data-countdown="${a.endsAt}">${formatCountdown(a.endsAt)}</span>
            </div>
            <div class="auction-tile__body">
              <h3>${escapeHtml(a.title)}</h3>
              <p class="auction-tile__price">${formatMoney(a.currentBid)} <span>current bid</span></p>
              <a class="btn btn-ghost btn-sm" href="/dashboard.html">Bid in app →</a>
            </div>
          </article>`;
        })
        .join("")}</div>`;

      setInterval(() => {
        host.querySelectorAll("[data-countdown]").forEach((el) => {
          el.textContent = formatCountdown(el.getAttribute("data-countdown"));
        });
      }, 1000);
    } catch {
      host.innerHTML = '<p class="hint">Could not load auctions. Is the server running?</p>';
    }
  }

  function initNavAuth() {
    const loginLink = document.getElementById("nav-login-link");
    const dashLink = document.getElementById("nav-dash-link");
    if (!loginLink || !dashLink) return;
    fetch("/api/auth/me", { credentials: "same-origin" })
      .then((r) => r.json())
      .then(({ user }) => {
        if (user) {
          loginLink.classList.add("hidden");
          dashLink.classList.remove("hidden");
        }
      })
      .catch(() => {});
  }

  initSlider();
  loadFeatured();
  initNavAuth();
})();

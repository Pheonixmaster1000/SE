/**
 * API client with optional loading UI and error toasts.
 * @param {string} path
 * @param {RequestInit} [options]
 * @param {{ loadingEl?: HTMLElement|null, toastOnError?: boolean, silent?: boolean }} [feedback]
 */
async function api(path, options = {}, feedback = {}) {
  const { loadingEl, toastOnError = false, silent = false } = feedback;
  if (loadingEl) {
    loadingEl.classList.add("is-loading");
    loadingEl.setAttribute("aria-busy", "true");
  }
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  try {
    const res = await fetch(path, {
      ...options,
      headers,
      credentials: "same-origin",
    });
    const text = await res.text();
    let data;
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = { raw: text };
    }
    if (!res.ok) {
      const err = new Error(data.error || res.statusText || "Request failed");
      err.status = res.status;
      err.body = data;
      throw err;
    }
    return data;
  } catch (e) {
    if (!silent && toastOnError && typeof window.showToast === "function") {
      const msg =
        e.name === "TypeError"
          ? "Network error — is the server running?"
          : e.body?.error || e.message || "Request failed";
      window.showToast(msg, "error");
    }
    throw e;
  } finally {
    if (loadingEl) {
      loadingEl.classList.remove("is-loading");
      loadingEl.removeAttribute("aria-busy");
    }
  }
}

window.api = api;

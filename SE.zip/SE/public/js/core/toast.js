(function () {
  function ensureHost() {
    let el = document.getElementById("toast-host");
    if (!el) {
      el = document.createElement("div");
      el.id = "toast-host";
      el.className = "toast-host";
      el.setAttribute("aria-live", "polite");
      document.body.appendChild(el);
    }
    return el;
  }

  function showToast(message, variant) {
    const host = ensureHost();
    const t = document.createElement("div");
    t.className = "toast toast--" + (variant || "error");
    t.textContent = message;
    host.appendChild(t);
    requestAnimationFrame(() => t.classList.add("toast--show"));
    setTimeout(() => {
      t.classList.remove("toast--show");
      setTimeout(() => t.remove(), 300);
    }, 4500);
  }

  window.showToast = showToast;
})();

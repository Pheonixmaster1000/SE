(function () {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s == null ? "" : String(s);
    return d.innerHTML;
  }

  function badgeFor(status) {
    if (status === "active") return '<span class="badge badge-active">active</span>';
    if (status === "pending") return '<span class="badge badge-pending">pending</span>';
    if (status === "ended") return '<span class="badge badge-ended">ended</span>';
    return `<span class="badge">${escapeHtml(status)}</span>`;
  }

  function minBid(a) {
    const base = a.currentBid != null ? a.currentBid : a.startingBid;
    const inc = a.minIncrement || 1;
    return base + inc;
  }

  function formatCountdown(iso) {
    const end = new Date(iso).getTime();
    const diff = end - Date.now();
    if (diff <= 0) return "Ended";
    const s = Math.floor(diff / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (d > 0) {
      return `${d}d ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
    }
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  }

  function tickCountdowns() {
    document.querySelectorAll("[data-countdown]").forEach((el) => {
      el.textContent = formatCountdown(el.getAttribute("data-countdown"));
    });
  }

  let currentUser = null;

  function notifyErr(e) {
    const msg = e.body?.error || e.message || "Something went wrong";
    if (typeof window.showToast === "function") window.showToast(msg, "error");
    else alert(msg);
  }

  function setPanels() {
    const r = currentUser.role;
    const map = {
      "panel-buyer": ["buyer", "seller", "admin", "support"],
      "panel-seller": ["seller", "admin"],
      "panel-support": ["support"],
      "panel-admin": ["admin"],
      "panel-tickets": ["buyer", "seller", "admin"],
    };
    Object.keys(map).forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.classList.toggle("is-visible", map[id].includes(r));
    });

    $("#role-subtitle").textContent =
      {
        buyer: "Place bids and open support tickets.",
        seller: "List items (pending admin approval) and bid as a buyer.",
        admin: "Full control: users, approvals, auctions, maintenance.",
        support: "Handle tickets and view accounts (read-only). Browse listings without bidding.",
      }[r] || "";

    $("#user-display").innerHTML =
      `${escapeHtml(currentUser.displayName || currentUser.username)} · <strong>${escapeHtml(r)}</strong>`;

    document.querySelectorAll("[data-show-role]").forEach((el) => {
      const need = el.getAttribute("data-show-role");
      el.classList.toggle("hidden", r !== need);
    });
  }

  async function loadBrowseAuctions() {
    const host = $("#buyer-auctions");
    let auctions;
    try {
      ({ auctions } = await api("/api/auctions", {}, { loadingEl: host, toastOnError: true }));
    } catch {
      return;
    }
    if (!auctions.length) {
      host.innerHTML = "<p class=\"hint\">No auctions yet.</p>";
      return;
    }
    const canBid = currentUser.role === "buyer" || currentUser.role === "admin";
    host.innerHTML = auctions
      .map((a) => {
        const next = minBid(a);
        const ended = a.status === "ended" || new Date(a.endsAt) <= new Date();
        const bidBlock =
          canBid && a.status === "active" && !ended
            ? `<div class="field" style="margin-top:0.75rem">
                 <label>Bid (min ${next})</label>
                 <div style="display:flex;gap:0.5rem;flex-wrap:wrap;align-items:center">
                   <input type="number" step="0.01" min="${next}" value="${next}" id="bid-${a.id}" style="max-width:160px" />
                   <button type="button" class="btn btn-primary btn-sm bid-btn" data-id="${a.id}">Place bid</button>
                 </div>
               </div>`
            : currentUser.role === "support"
              ? "<p class=\"hint\">Support role cannot place bids.</p>"
              : "";
        const img = escapeHtml(a.imageUrl || "");
        const alt = escapeHtml(a.title);
        return `<article class="auction-card card auction-card-v2" data-id="${a.id}">
          <div class="auction-card__media">
            <img src="${img}" alt="${alt}" loading="lazy" width="400" height="250" />
            <span class="auction-card__timer" data-countdown="${a.endsAt}">${formatCountdown(a.endsAt)}</span>
          </div>
          <div class="auction-card__body">
          <div class="flex-between">
            <h3>${escapeHtml(a.title)}</h3>
            ${badgeFor(a.status)}
          </div>
          <p class="meta">Seller: ${escapeHtml(a.sellerName)} · Ends ${new Date(a.endsAt).toLocaleString()}</p>
          <p>${escapeHtml(a.description || "")}</p>
          <p><strong>Current:</strong> $${escapeHtml(a.currentBid)} &nbsp; <strong>Next min:</strong> $${next}</p>
          ${bidBlock}
          </div>
        </article>`;
      })
      .join("");

    host.querySelectorAll(".bid-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        const input = document.getElementById(`bid-${id}`);
        const amount = Number(input.value);
        try {
          await api(
            `/api/auctions/${id}/bid`,
            {
              method: "POST",
              body: JSON.stringify({ amount }),
            },
            { toastOnError: true }
          );
          if (typeof window.showToast === "function") window.showToast("Bid placed", "success");
          await loadBrowseAuctions();
        } catch {
          /* error toast from api() */
        }
      });
    });
    tickCountdowns();
  }

  async function loadSellerAuctions() {
    const host = $("#seller-auctions");
    let auctions;
    try {
      ({ auctions } = await api("/api/auctions?mine=1", {}, { loadingEl: host, toastOnError: true }));
    } catch {
      return;
    }
    if (!auctions.length) {
      host.innerHTML = "<p class=\"hint\">You have no listings yet.</p>";
      return;
    }
    host.innerHTML = auctions
      .map((a) => {
        const img = escapeHtml(a.imageUrl || "");
        const alt = escapeHtml(a.title);
        return `<article class="auction-card card auction-card-v2">
      <div class="auction-card__media">
        <img src="${img}" alt="${alt}" loading="lazy" width="400" height="250" />
        <span class="auction-card__timer" data-countdown="${a.endsAt}">${formatCountdown(a.endsAt)}</span>
      </div>
      <div class="auction-card__body">
      <div class="flex-between">
        <h3>${escapeHtml(a.title)}</h3>
        ${badgeFor(a.status)}
      </div>
      <p class="meta">Ends ${new Date(a.endsAt).toLocaleString()}</p>
      <p><strong>Current bid:</strong> $${escapeHtml(a.currentBid)}</p>
      </div>
    </article>`;
      })
      .join("");
    tickCountdowns();
  }

  async function loadUserTickets() {
    const host = $("#user-tickets");
    let tickets;
    try {
      ({ tickets } = await api("/api/tickets", {}, { loadingEl: host, toastOnError: true }));
    } catch {
      return;
    }
    if (!tickets.length) {
      host.innerHTML = "<p class=\"hint\">No tickets yet.</p>";
      return;
    }
    host.innerHTML = tickets
      .map(
        (t) => `<div class="card" style="padding:1rem;margin-bottom:0.75rem">
      <div class="flex-between">
        <strong>${escapeHtml(t.subject)}</strong>
        <span class="badge">${escapeHtml(t.status)}</span>
      </div>
      <p class="hint" style="margin:0.5rem 0">${escapeHtml(t.body).slice(0, 200)}${t.body.length > 200 ? "…" : ""}</p>
    </div>`
      )
      .join("");
  }

  async function loadSupportUsers() {
    const host = $("#support-users");
    let users;
    try {
      ({ users } = await api("/api/admin/users", {}, { loadingEl: host, toastOnError: true }));
    } catch {
      return;
    }
    host.innerHTML = `<table><thead><tr>
      <th>Name</th><th>Username</th><th>Role</th><th>Active</th>
    </tr></thead><tbody>
      ${users
        .map(
          (u) => `<tr>
        <td>${escapeHtml(u.displayName || "—")}</td>
        <td>${escapeHtml(u.username)}</td>
        <td>${escapeHtml(u.role)}</td>
        <td>${u.active ? "yes" : "no"}</td>
      </tr>`
        )
        .join("")}
    </tbody></table>`;
  }

  async function loadSupportTickets() {
    const host = $("#support-tickets");
    let tickets;
    try {
      ({ tickets } = await api("/api/tickets", {}, { loadingEl: host, toastOnError: true }));
    } catch {
      return;
    }
    host.innerHTML = `<div class="table-wrap"><table><thead><tr>
      <th>Subject</th><th>Status</th><th>Priority</th><th>Updated</th><th></th>
    </tr></thead><tbody>
      ${tickets
        .map(
          (t) => `<tr>
        <td>${escapeHtml(t.subject)}</td>
        <td>${escapeHtml(t.status)}</td>
        <td>${escapeHtml(t.priority)}</td>
        <td>${new Date(t.updatedAt).toLocaleString()}</td>
        <td><button type="button" class="btn btn-ghost btn-sm ticket-open" data-id="${t.id}">Edit</button></td>
      </tr>`
        )
        .join("")}
    </tbody></table></div>`;

    host.querySelectorAll(".ticket-open").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id");
        const t = tickets.find((x) => x.id === id);
        $("#form-ticket-note").classList.remove("hidden");
        $("#ticket-edit-id").value = id;
        $("#ticket-internal-note").value = t.internalNote || "";
        $("#ticket-status").value = t.status;
      });
    });
  }

  async function loadAdmin() {
    let users;
    let pendingRes;
    let allRes;
    try {
      [users, pendingRes, allRes] = await Promise.all([
        api("/api/admin/users", {}, { toastOnError: true }).then((r) => r.users),
        api("/api/auctions?status=pending", {}, { toastOnError: false }).catch(() => ({ auctions: [] })),
        api("/api/auctions", {}, { toastOnError: true }),
      ]);
      pendingRes = pendingRes || { auctions: [] };
      allRes = allRes || { auctions: [] };
    } catch {
      return;
    }
    users = users || [];

    const pending = pendingRes.auctions || [];
    const all = allRes.auctions || [];

    $("#admin-pending").innerHTML = pending.length
      ? `<div class="auction-list auction-list--grid">${pending
          .map(
            (a) => {
              const img = escapeHtml(a.imageUrl || "");
              const alt = escapeHtml(a.title);
              return `<article class="auction-card card auction-card-v2">
          <div class="auction-card__media">
            <img src="${img}" alt="${alt}" loading="lazy" width="200" height="120" />
          </div>
          <div class="auction-card__body">
          <div class="flex-between">
            <h3>${escapeHtml(a.title)}</h3>
            ${badgeFor(a.status)}
          </div>
          <p>${escapeHtml(a.description || "").slice(0, 160)}…</p>
          <button type="button" class="btn btn-primary btn-sm approve-btn" data-id="${a.id}">Approve</button>
          </div>
        </article>`;
            }
          )
          .join("")}</div>`
      : "<p class=\"hint\">No pending listings.</p>";

    $("#admin-pending").querySelectorAll(".approve-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        try {
          await api(`/api/admin/auctions/${id}/approve`, { method: "POST", body: "{}" }, { toastOnError: true });
          await loadAdmin();
          await loadBrowseAuctions();
        } catch {
          /* toasted */
        }
      });
    });

    $("#admin-users").innerHTML = `<table><thead><tr>
      <th>User</th><th>Role</th><th>Active</th><th>Actions</th>
    </tr></thead><tbody>
      ${users
        .map((u) => {
          const canEdit = currentUser.role === "admin";
          return `<tr>
            <td>${escapeHtml(u.displayName || u.username)} (${escapeHtml(u.username)})</td>
            <td>${escapeHtml(u.role)}</td>
            <td>${u.active ? "yes" : "no"}</td>
            <td>
              ${
                canEdit
                  ? `<button type="button" class="btn btn-ghost btn-sm toggle-user" data-id="${u.id}" data-active="${u.active}">${u.active ? "Deactivate" : "Activate"}</button>
                     <select class="role-select" data-id="${u.id}" style="max-width:120px">
                       ${["buyer", "seller", "admin", "support"]
                         .map((r) => `<option value="${r}" ${u.role === r ? "selected" : ""}>${r}</option>`)
                         .join("")}
                     </select>`
                  : "—"
              }
            </td>
          </tr>`;
        })
        .join("")}
    </tbody></table>`;

    $("#admin-users").querySelectorAll(".toggle-user").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        const active = btn.getAttribute("data-active") === "true";
        try {
          await api(
            `/api/admin/users/${id}`,
            { method: "PATCH", body: JSON.stringify({ active: !active }) },
            { toastOnError: true }
          );
          await loadAdmin();
        } catch {
          /* toasted */
        }
      });
    });

    $("#admin-users").querySelectorAll(".role-select").forEach((sel) => {
      sel.addEventListener("change", async () => {
        const id = sel.getAttribute("data-id");
        const role = sel.value;
        try {
          await api(
            `/api/admin/users/${id}`,
            { method: "PATCH", body: JSON.stringify({ role }) },
            { toastOnError: true }
          );
          await loadAdmin();
        } catch {
          /* toasted */
        }
      });
    });

    $("#admin-auctions").innerHTML = all.length
      ? `<div class="auction-list auction-list--grid">${all
          .map(
            (a) => {
              const img = escapeHtml(a.imageUrl || "");
              const alt = escapeHtml(a.title);
              return `<article class="auction-card card auction-card-v2">
        <div class="auction-card__media">
          <img src="${img}" alt="${alt}" loading="lazy" width="200" height="120" />
          <span class="auction-card__timer" data-countdown="${a.endsAt}">${formatCountdown(a.endsAt)}</span>
        </div>
        <div class="auction-card__body">
        <div class="flex-between">
          <h3>${escapeHtml(a.title)}</h3>
          ${badgeFor(a.status)}
        </div>
        <p class="meta">${escapeHtml(a.sellerName)}</p>
        <button type="button" class="btn btn-danger btn-sm del-auct" data-id="${a.id}">Delete</button>
        </div>
      </article>`;
            }
          )
          .join("")}</div>`
      : "<p class=\"hint\">No auctions.</p>";
    tickCountdowns();

    $("#admin-auctions").querySelectorAll(".del-auct").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete this auction?")) return;
        const id = btn.getAttribute("data-id");
        try {
          await api(`/api/admin/auctions/${id}`, { method: "DELETE" }, { toastOnError: true });
          await loadAdmin();
          await loadBrowseAuctions();
        } catch {
          /* toasted */
        }
      });
    });
  }

  $("#btn-logout").addEventListener("click", async () => {
    await api("/api/auth/logout", { method: "POST", body: "{}" });
    window.location.href = "/";
  });

  $("#btn-refresh-auctions").addEventListener("click", () => loadBrowseAuctions());

  $("#form-new-listing").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const endsAt = fd.get("endsAt");
    const payload = {
      title: fd.get("title"),
      description: fd.get("description") || "",
      startingBid: Number(fd.get("startingBid")),
      minIncrement: fd.get("minIncrement") ? Number(fd.get("minIncrement")) : undefined,
      endsAt: new Date(endsAt).toISOString(),
      imageUrl: fd.get("imageUrl") ? String(fd.get("imageUrl")).trim() : undefined,
    };
    if (!payload.imageUrl) delete payload.imageUrl;
    const box = $("#seller-alert");
    box.innerHTML = "";
    try {
      await api("/api/auctions", { method: "POST", body: JSON.stringify(payload) });
      box.innerHTML = '<div class="alert alert-success">Listing submitted for approval.</div>';
      e.target.reset();
      await loadSellerAuctions();
    } catch (err) {
      box.innerHTML = `<div class="alert alert-error">${escapeHtml(err.body?.error || err.message)}</div>`;
    }
  });

  $("#form-new-ticket").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api("/api/tickets", {
        method: "POST",
        body: JSON.stringify({
          subject: fd.get("subject"),
          body: fd.get("body"),
          priority: fd.get("priority"),
        }),
      });
      e.target.reset();
      await loadUserTickets();
    } catch (err) {
      notifyErr(err);
    }
  });

  $("#form-ticket-note").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = $("#ticket-edit-id").value;
    try {
      await api(`/api/tickets/${id}`, {
        method: "PATCH",
        body: JSON.stringify({
          status: $("#ticket-status").value,
          internalNote: $("#ticket-internal-note").value,
        }),
      });
      $("#form-ticket-note").classList.add("hidden");
      await loadSupportTickets();
    } catch (err) {
      notifyErr(err);
    }
  });

  $("#btn-close-ended").addEventListener("click", async () => {
    try {
      await api("/api/admin/maintenance/close-ended", { method: "POST", body: "{}" });
      await loadBrowseAuctions();
      await loadAdmin();
    } catch (e) {
      notifyErr(e);
    }
  });

  $("#btn-refresh-admin").addEventListener("click", async () => {
    await loadAdmin();
    await loadBrowseAuctions();
  });

  async function init() {
    let me;
    try {
      me = await api("/api/auth/me", {}, { toastOnError: false });
    } catch {
      window.location.href = "/";
      return;
    }
    if (!me.user) {
      window.location.href = "/";
      return;
    }
    currentUser = me.user;
    setPanels();

    await loadBrowseAuctions();
    if (currentUser.role === "seller" || currentUser.role === "admin") {
      await loadSellerAuctions();
    }
    if (["buyer", "seller", "admin"].includes(currentUser.role)) {
      await loadUserTickets();
    }
    if (currentUser.role === "support") {
      await loadSupportTickets();
      await loadSupportUsers();
    }
    if (currentUser.role === "admin") {
      await loadAdmin();
    }

    tickCountdowns();
    setInterval(tickCountdowns, 1000);
  }

  init();
})();

const { describe, it, before } = require("node:test");
const assert = require("node:assert/strict");
const bcrypt = require("bcryptjs");
const { verifyPassword } = require("../lib/store");

describe("verifyPassword (bcrypt)", () => {
  let hash;
  before(async () => {
    hash = await bcrypt.hash("secret-pass", 8);
  });

  it("returns true for correct password", async () => {
    const ok = await verifyPassword({ passwordHash: hash }, "secret-pass");
    assert.equal(ok, true);
  });

  it("returns false for wrong password", async () => {
    const ok = await verifyPassword({ passwordHash: hash }, "wrong");
    assert.equal(ok, false);
  });
});

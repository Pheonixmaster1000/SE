const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const { validateBid, minNextBid } = require("../lib/bidding");

const baseAuction = {
  id: "a1",
  sellerId: "seller-1",
  status: "active",
  startingBid: 100,
  currentBid: 100,
  minIncrement: 5,
  endsAt: new Date(Date.now() + 3600_000).toISOString(),
};

describe("validateBid", () => {
  it("rejects self-bid", () => {
    const r = validateBid(baseAuction, "seller-1", 105);
    assert.equal(r.ok, false);
    assert.equal(r.code, "OWN_AUCTION");
  });

  it("rejects bid below minimum", () => {
    const r = validateBid(baseAuction, "buyer-1", 104);
    assert.equal(r.ok, false);
    assert.equal(r.code, "LOW");
    assert.equal(r.minNext, 105);
  });

  it("accepts valid bid", () => {
    const r = validateBid(baseAuction, "buyer-1", 105);
    assert.equal(r.ok, true);
    assert.equal(r.bidAmount, 105);
  });

  it("rejects ended auction by time", () => {
    const past = {
      ...baseAuction,
      endsAt: new Date(Date.now() - 1000).toISOString(),
    };
    const r = validateBid(past, "buyer-1", 200);
    assert.equal(r.ok, false);
    assert.equal(r.code, "ENDED");
  });

  it("computes minNextBid", () => {
    assert.equal(minNextBid(baseAuction), 105);
  });
});

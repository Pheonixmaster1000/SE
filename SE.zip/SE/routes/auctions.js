const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../lib/db");
const store = require("../lib/store");
const { requireAuth, requireRoles } = require("../lib/middleware");
const { validateBody, schemas } = require("../lib/validation");
const { asyncHandler } = require("../middleware/asyncHandler");
const { sanitizeResolvedImage } = require("../lib/imageUrl");
const { isValidListingImageUrl } = require("../lib/imageUrl");
const { validateBid } = require("../lib/bidding");
const rateLimits = require("../middleware/rateLimits");
const { AppError } = require("../lib/errors");

const router = express.Router();

function enrichAuction(a, session) {
  const seller = store.findUserById(a.sellerId);
  const out = {
    ...a,
    sellerName: seller ? seller.displayName || seller.username : "Unknown",
    imageUrl: sanitizeResolvedImage(a),
  };
  if (!session || session.role !== "admin") {
    delete out.internalNote;
  }
  return out;
}

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const { mine, status } = req.query;
    const data = store.getAuctionsData();
    let list = [...(data.auctions || [])];

    if (req.session && req.session.userId && mine === "1" && req.session.role === "seller") {
      list = list.filter((a) => a.sellerId === req.session.userId);
    } else if (req.session && req.session.role === "admin") {
      if (status) list = list.filter((a) => a.status === status);
    } else {
      list = list.filter((a) => a.status === "active" || a.status === "ended");
    }

    const enriched = list.map((a) => enrichAuction(a, req.session));
    enriched.sort((a, b) => new Date(b.endsAt) - new Date(a.endsAt));
    res.json({ auctions: enriched });
  })
);

router.post(
  "/:id/bid",
  requireAuth,
  requireRoles("buyer", "admin"),
  rateLimits.bid,
  validateBody(schemas.bid),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const bidAmount = req.validated.amount;
    const bidderId = req.session.userId;

    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      const auctions = data.auctions || [];
      const idx = auctions.findIndex((x) => x.id === id);
      if (idx === -1) throw new AppError("Auction not found", 404, "NOT_FOUND");
      const a = { ...auctions[idx] };

      const v = validateBid(a, bidderId, bidAmount, new Date());
      if (v.code === "ENDED") {
        a.status = "ended";
        auctions[idx] = a;
        data.auctions = auctions;
        throw new AppError("Auction has ended", 400, "ENDED");
      }
      if (!v.ok) {
        const min = v.minNext;
        const msg =
          v.code === "LOW"
            ? `Bid must be at least ${min != null ? min.toFixed(2) : "minimum"}`
            : mapBidErr(v.code);
        throw new AppError(msg, 400, v.code);
      }

      a.currentBid = v.bidAmount;
      a.currentBidderId = bidderId;
      a.bids = a.bids || [];
      a.bids.push({
        bidderId,
        amount: v.bidAmount,
        at: new Date().toISOString(),
      });
      auctions[idx] = a;
      data.auctions = auctions;
      return data;
    });

    const data = store.getAuctionsData();
    const a = data.auctions.find((x) => x.id === id);
    const bidder = store.findUserById(bidderId);
    res.json({
      auction: enrichAuction(a, req.session),
      message: `Bid placed: ${bidAmount} by ${bidder ? bidder.displayName : bidderId}`,
    });
  })
);

function mapBidErr(code) {
  const m = {
    NOT_FOUND: "Auction not found",
    NOT_ACTIVE: "Auction is not active",
    OWN_AUCTION: "Cannot bid on your own listing",
    INVALID_AMOUNT: "Invalid bid amount",
    TOO_LARGE: "Amount too large",
    TOO_MANY_DECIMALS: "Use at most 2 decimal places",
    LOW: "Bid too low",
  };
  return m[code] || "Cannot place bid";
}

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const data = store.getAuctionsData();
    const a = data.auctions.find((x) => x.id === req.params.id);
    if (!a) return res.status(404).json({ error: "Not found", code: "NOT_FOUND" });
    const session = req.session;
    if (a.status === "pending" && (!session || session.role !== "admin")) {
      const isSeller = session && session.userId === a.sellerId;
      if (!isSeller) return res.status(404).json({ error: "Not found", code: "NOT_FOUND" });
    }
    res.json({ auction: enrichAuction(a, session) });
  })
);

router.post(
  "/",
  requireAuth,
  requireRoles("seller", "admin"),
  validateBody(schemas.createAuction),
  asyncHandler(async (req, res) => {
    const body = req.validated;
    const start = Number(body.startingBid);
    const inc =
      body.minIncrement != null ? Number(body.minIncrement) : Math.max(1, Math.round(start * 0.05));
    const endDate = body.endsAt instanceof Date ? body.endsAt : new Date(body.endsAt);

    const sellerId =
      req.session.role === "admin" && body.sellerId ? body.sellerId : req.session.userId;

    let img = body.imageUrl != null ? String(body.imageUrl).trim() : "";
    if (img && !isValidListingImageUrl(img)) {
      throw new AppError("Invalid imageUrl", 400, "BAD_IMAGE");
    }

    const auction = {
      id: uuidv4(),
      title: body.title,
      description: body.description || "",
      sellerId,
      startingBid: start,
      currentBid: start,
      currentBidderId: null,
      minIncrement: inc,
      status: req.session.role === "admin" ? "active" : "pending",
      endsAt: endDate.toISOString(),
      createdAt: new Date().toISOString(),
      bids: [],
      ...(img ? { imageUrl: img } : {}),
    };

    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      data.auctions = data.auctions || [];
      data.auctions.push(auction);
      return data;
    });
    res.status(201).json({ auction: enrichAuction(auction, req.session) });
  })
);

router.patch(
  "/:id",
  requireAuth,
  requireRoles("seller", "admin"),
  validateBody(schemas.patchAuction),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const body = req.validated;

    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      const auctions = data.auctions || [];
      const idx = auctions.findIndex((x) => x.id === id);
      if (idx === -1) throw new AppError("Not found", 404, "NOT_FOUND");
      const a = auctions[idx];
      if (req.session.role !== "admin" && a.sellerId !== req.session.userId) {
        throw new AppError("Forbidden", 403, "FORBIDDEN");
      }
      if (req.session.role === "seller" && a.status !== "pending" && a.status !== "active") {
        throw new AppError("Cannot edit this listing", 400, "LOCKED");
      }
      if (body.title != null) a.title = body.title;
      if (body.description != null) a.description = body.description;
      if (body.minIncrement != null) a.minIncrement = body.minIncrement;
      if (body.imageUrl !== undefined) {
        const img = body.imageUrl != null ? String(body.imageUrl).trim() : "";
        if (img && !isValidListingImageUrl(img)) throw new AppError("Invalid imageUrl", 400, "BAD_IMAGE");
        if (img) a.imageUrl = img;
        else delete a.imageUrl;
      }
      if (body.endsAt != null) {
        const d = body.endsAt instanceof Date ? body.endsAt : new Date(body.endsAt);
        if (!Number.isNaN(d.getTime()) && d > new Date()) a.endsAt = d.toISOString();
      }
      auctions[idx] = a;
      data.auctions = auctions;
      return data;
    });

    const data = store.getAuctionsData();
    const a = data.auctions.find((x) => x.id === id);
    res.json({ auction: enrichAuction(a, req.session) });
  })
);

module.exports = { router, enrichAuction };

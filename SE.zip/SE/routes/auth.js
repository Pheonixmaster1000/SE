const express = require("express");
const store = require("../lib/store");
const { validateBody, schemas } = require("../lib/validation");
const { asyncHandler } = require("../middleware/asyncHandler");
const rateLimits = require("../middleware/rateLimits");

const router = express.Router();

router.post(
  "/login",
  rateLimits.login,
  validateBody(schemas.login),
  asyncHandler(async (req, res) => {
    const { username, password } = req.validated;
    const user = store.findUserByUsername(username);
    if (!user || !user.active) {
      return res.status(401).json({ error: "Invalid credentials", code: "AUTH_FAILED" });
    }
    const ok = await store.verifyPassword(user, password);
    if (!ok) return res.status(401).json({ error: "Invalid credentials", code: "AUTH_FAILED" });
    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.username = user.username;
    res.json({ user: store.publicUser(user) });
  })
);

router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

router.get(
  "/me",
  asyncHandler(async (req, res) => {
    if (!req.session || !req.session.userId) {
      return res.json({ user: null });
    }
    const user = store.findUserById(req.session.userId);
    if (!user || !user.active) {
      req.session.destroy(() => res.json({ user: null }));
      return;
    }
    res.json({ user: store.publicUser(user) });
  })
);

router.post(
  "/register",
  rateLimits.register,
  validateBody(schemas.register),
  asyncHandler(async (req, res) => {
    const { username, password, email, displayName } = req.validated;
    try {
      const user = await store.createUser({
        username,
        password,
        role: "buyer",
        email: email || "",
        displayName: displayName && displayName.trim() ? displayName.trim() : username,
      });
      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.username = user.username;
      res.status(201).json({ user: store.publicUser(user) });
    } catch (e) {
      if (e.message === "USERNAME_TAKEN") {
        return res.status(409).json({ error: "Username already taken", code: "USERNAME_TAKEN" });
      }
      throw e;
    }
  })
);

module.exports = router;

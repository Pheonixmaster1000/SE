const express = require("express");
const { v4: uuidv4 } = require("uuid");
const db = require("../lib/db");
const store = require("../lib/store");
const { requireAuth } = require("../lib/middleware");
const { validateBody, schemas } = require("../lib/validation");
const { asyncHandler } = require("../middleware/asyncHandler");
const { AppError } = require("../lib/errors");

const router = express.Router();

router.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const data = store.getTicketsData();
    let tickets = data.tickets || [];
    if (req.session.role !== "support" && req.session.role !== "admin") {
      tickets = tickets.filter((t) => t.userId === req.session.userId);
    }
    tickets.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    res.json({ tickets });
  })
);

router.post(
  "/",
  requireAuth,
  validateBody(schemas.ticketCreate),
  asyncHandler(async (req, res) => {
    const { subject, body: ticketText, priority } = req.validated;
    const ticket = {
      id: uuidv4(),
      userId: req.session.userId,
      subject,
      body: ticketText,
      status: "open",
      priority: priority || "normal",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await db.writeJsonSafe(store.TICKETS, async (data) => {
      data.tickets = data.tickets || [];
      data.tickets.push(ticket);
      return data;
    });
    res.status(201).json({ ticket });
  })
);

router.patch(
  "/:id",
  requireAuth,
  validateBody(schemas.ticketPatch),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { status, internalNote } = req.validated;

    await db.writeJsonSafe(store.TICKETS, async (data) => {
      const tickets = data.tickets || [];
      const idx = tickets.findIndex((t) => t.id === id);
      if (idx === -1) throw new AppError("Not found", 404, "NOT_FOUND");
      const t = { ...tickets[idx] };

      if (req.session.role === "support" || req.session.role === "admin") {
        if (status) t.status = status;
        if (internalNote != null) t.internalNote = internalNote;
      } else if (t.userId === req.session.userId) {
        if (status === "closed") t.status = "closed";
      } else {
        throw new AppError("Forbidden", 403, "FORBIDDEN");
      }
      t.updatedAt = new Date().toISOString();
      tickets[idx] = t;
      data.tickets = tickets;
      return data;
    });

    const data = store.getTicketsData();
    const t = data.tickets.find((x) => x.id === id);
    res.json({ ticket: t });
  })
);

module.exports = router;

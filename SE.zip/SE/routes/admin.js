const express = require("express");
const db = require("../lib/db");
const store = require("../lib/store");
const { requireAuth, requireRoles } = require("../lib/middleware");
const { validateBody, schemas } = require("../lib/validation");
const { asyncHandler } = require("../middleware/asyncHandler");
const { AppError } = require("../lib/errors");
const { enrichAuction } = require("./auctions");

const router = express.Router();

router.get(
  "/users",
  requireAuth,
  requireRoles("admin", "support"),
  asyncHandler(async (req, res) => {
    const { users } = store.getUsersData();
    const list = users.map((u) => store.publicUser(u));
    res.json({ users: list });
  })
);

router.patch(
  "/users/:id",
  requireAuth,
  requireRoles("admin"),
  validateBody(schemas.adminUserPatch),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { active, role } = req.validated;
    if (id === req.session.userId && active === false) {
      throw new AppError("Cannot deactivate yourself", 400, "INVALID_OP");
    }

    await db.writeJsonSafe(store.USERS, async (data) => {
      const users = data.users || [];
      const idx = users.findIndex((u) => u.id === id);
      if (idx === -1) throw new AppError("Not found", 404, "NOT_FOUND");
      const u = { ...users[idx] };
      if (active != null) u.active = Boolean(active);
      if (role) {
        if (u.id === req.session.userId && role !== "admin") {
          throw new AppError("Cannot change own admin role this way", 400, "SELF_DEMOTE");
        }
        u.role = role;
      }
      users[idx] = u;
      data.users = users;
      return data;
    });

    const u = store.findUserById(id);
    res.json({ user: store.publicUser(u) });
  })
);

router.post(
  "/auctions/:id/approve",
  requireAuth,
  requireRoles("admin"),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      const auctions = data.auctions || [];
      const idx = auctions.findIndex((a) => a.id === id);
      if (idx === -1) throw new AppError("Not found", 404, "NOT_FOUND");
      const a = { ...auctions[idx] };
      if (a.status !== "pending") throw new AppError("Only pending listings can be approved", 400, "INVALID");
      a.status = "active";
      auctions[idx] = a;
      data.auctions = auctions;
      return data;
    });

    const a = store.getAuctionsData().auctions.find((x) => x.id === id);
    res.json({ auction: enrichAuction(a, req.session) });
  })
);

router.delete(
  "/auctions/:id",
  requireAuth,
  requireRoles("admin"),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      data.auctions = (data.auctions || []).filter((a) => a.id !== id);
      return data;
    });
    res.json({ ok: true });
  })
);

router.post(
  "/maintenance/close-ended",
  requireAuth,
  requireRoles("admin"),
  asyncHandler(async (req, res) => {
    const now = new Date();
    await db.writeJsonSafe(store.AUCTIONS, async (data) => {
      const auctions = data.auctions || [];
      for (let i = 0; i < auctions.length; i++) {
        const a = auctions[i];
        if (a.status === "active" && new Date(a.endsAt) <= now) {
          a.status = "ended";
          auctions[i] = a;
        }
      }
      data.auctions = auctions;
      return data;
    });
    res.json({ ok: true });
  })
);

module.exports = router;

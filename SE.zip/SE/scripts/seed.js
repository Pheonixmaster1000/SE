const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

/** Default password for buyer1 / seller1 (override with SEED_PASSWORD) */
const defaultPass = process.env.SEED_PASSWORD || "Auction123!";

const IMG = {
  camera:
    "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=80",
  keyboard:
    "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80",
  watch:
    "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
  headphones:
    "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
};

const users = {
  users: [
    {
      id: uuidv4(),
      username: "buyer1",
      passwordHash: bcrypt.hashSync(defaultPass, 12),
      role: "buyer",
      email: "buyer@example.com",
      displayName: "Alex Buyer",
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      username: "seller1",
      passwordHash: bcrypt.hashSync(defaultPass, 12),
      role: "seller",
      email: "seller@example.com",
      displayName: "Sam Seller",
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      username: "admin",
      passwordHash: bcrypt.hashSync("admin", 12),
      role: "admin",
      email: "admin@example.com",
      displayName: "Admin",
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: uuidv4(),
      username: "support",
      passwordHash: bcrypt.hashSync("support", 12),
      role: "support",
      email: "support@example.com",
      displayName: "Support Agent",
      active: true,
      createdAt: new Date().toISOString(),
    },
  ],
};

const sellerId = users.users.find((u) => u.username === "seller1").id;

const auctions = {
  auctions: [
    {
      id: uuidv4(),
      title: "Vintage Camera — Leica M3",
      description: "Fully serviced, includes leather case. Shutter accurate at all speeds.",
      imageUrl: IMG.camera,
      sellerId,
      startingBid: 1200,
      currentBid: 1450,
      currentBidderId: null,
      minIncrement: 25,
      status: "active",
      endsAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      bids: [],
    },
    {
      id: uuidv4(),
      title: "Mechanical Keyboard — Custom Build",
      description: "Lubed switches, brass plate, hot-swap PCB.",
      imageUrl: IMG.keyboard,
      sellerId,
      startingBid: 180,
      currentBid: 180,
      currentBidderId: null,
      minIncrement: 10,
      status: "active",
      endsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      bids: [],
    },
    {
      id: uuidv4(),
      title: "Minimalist Watch — Swiss Movement",
      description: "Sapphire crystal, 40mm case, full box and papers.",
      imageUrl: IMG.watch,
      sellerId,
      startingBid: 450,
      currentBid: 520,
      currentBidderId: null,
      minIncrement: 15,
      status: "active",
      endsAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      bids: [],
    },
    {
      id: uuidv4(),
      title: "Wireless Studio Headphones",
      description: "Noise cancelling, 30h battery, travel case included.",
      imageUrl: IMG.headphones,
      sellerId,
      startingBid: 95,
      currentBid: 95,
      currentBidderId: null,
      minIncrement: 5,
      status: "active",
      endsAt: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      bids: [],
    },
  ],
};

const tickets = {
  tickets: [
    {
      id: uuidv4(),
      userId: users.users.find((u) => u.username === "buyer1").id,
      subject: "Question about shipping for camera lot",
      body: "Do you ship internationally?",
      status: "open",
      priority: "normal",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ],
};

fs.writeFileSync(path.join(dataDir, "users.json"), JSON.stringify(users, null, 2), "utf8");
fs.writeFileSync(path.join(dataDir, "auctions.json"), JSON.stringify(auctions, null, 2), "utf8");
fs.writeFileSync(path.join(dataDir, "tickets.json"), JSON.stringify(tickets, null, 2), "utf8");

console.log("Seeded data/users.json, data/auctions.json, data/tickets.json");
console.log("Credentials: buyer1 & seller1 →", defaultPass, "| admin → admin | support → support");

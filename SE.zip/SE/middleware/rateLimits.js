const rateLimit = require("express-rate-limit");

const login = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many login attempts, try again later.", code: "RATE_LIMIT" },
});

const register = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many registrations from this IP.", code: "RATE_LIMIT" },
});

const bid = rateLimit({
  windowMs: 60 * 1000,
  max: 45,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many bids — slow down.", code: "RATE_LIMIT" },
});

const apiGlobal = rateLimit({
  windowMs: 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests.", code: "RATE_LIMIT" },
});

module.exports = { login, register, bid, apiGlobal };

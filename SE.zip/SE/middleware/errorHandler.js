const logger = require("../lib/logger");
const { AppError } = require("../lib/errors");

function notFoundHandler(req, res) {
  res.status(404).json({ error: "Not found", code: "NOT_FOUND" });
}

function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  if (err.name === "ValidationError") {
    return res.status(400).json({ error: err.message, code: "VALIDATION_ERROR" });
  }

  if (err instanceof AppError) {
    logger.warn(`AppError: ${err.message}`, { code: err.code });
    return res.status(err.statusCode).json({ error: err.message, code: err.code });
  }

  const code = err.code === "EBADCSRF" ? 403 : 500;
  const status = err.statusCode || code;
  logger.error(`Unhandled: ${req.method} ${req.originalUrl}`, err);
  res.status(status).json({
    error: process.env.NODE_ENV === "production" ? "Internal server error" : err.message,
    code: "INTERNAL_ERROR",
  });
}

module.exports = { notFoundHandler, errorHandler };
